A stand-in for run_designer_on_windows.R
