A stand-in for rundesigner.vbs
